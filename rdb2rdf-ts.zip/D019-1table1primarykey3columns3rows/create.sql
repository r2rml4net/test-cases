CREATE TABLE "Employee" (
"ID" INTEGER,
"FirstName" VARCHAR(50),
"LastName" VARCHAR(50)
);
INSERT INTO "Employee" ("ID","FirstName","LastName") VALUES (10,'http://example.com/ns#Jhon','Smith');
INSERT INTO "Employee" ("ID","FirstName","LastName") VALUES (20,'Carlos','Mendoza');
INSERT INTO "Employee" ("ID","FirstName","LastName") VALUES (30,'Juan Daniel','Crespo');