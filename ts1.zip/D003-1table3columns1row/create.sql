CREATE TABLE "Student" (
"ID" integer,
"FirstName" varchar(50),
"LastName" varchar(50)
);
INSERT INTO "Student" ("ID", "FirstName", "LastName") VALUES (10,'Venus', 'Williams');
