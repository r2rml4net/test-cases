CREATE TABLE "IOUs" (
      "fname" CHAR(20),
      "lname"  CHAR(20),
      "amount" FLOAT);
INSERT INTO "IOUs" ("fname", "lname", "amount") VALUES ('Bob', 'Smith', 30);
INSERT INTO "IOUs" ("fname", "lname", "amount") VALUES ('Sue', 'Jones', 20);
INSERT INTO "IOUs" ("fname", "lname", "amount") VALUES ('Bob', 'Smith', 30);
